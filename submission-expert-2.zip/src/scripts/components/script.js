import './nav-bar.js';
import './hero-section.js';
import './content-item.js';
import './foot-bar.js';